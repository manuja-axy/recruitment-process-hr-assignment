# Candidate Interview Evaluation Sheet

Each interviewer completes one sheet per candidate straight after the interview, scoring independently before the panel discusses.

## Candidate details

| Field | Entry |
| --- | --- |
| Candidate name and ID | |
| Position applied for | Business Development Executive / HR Executive |
| Interview round | Functional round / Final round |
| Date and time | |
| Interviewer(s) | |
| Mode | In person / Video |

## Rating scale

| Rating | Meaning |
| --- | --- |
| 5 | Excellent: clear, structured, specific examples, exceeds expectations for a fresher |
| 4 | Good: meets expectations with minor gaps |
| 3 | Average: acceptable but generic or partly vague |
| 2 | Below average: significant gaps, needs heavy coaching |
| 1 | Poor: unable to answer or unsuitable |

## Competency scoring

Weighted score = (rating / 5) x weight.

| Competency | Weight | Rating (1 to 5) | Weighted score | Evidence and comments |
| --- | --- | --- | --- | --- |
| Communication and presence | 15 | | | |
| Role knowledge | 20 | | | |
| Problem solving and thinking | 15 | | | |
| Customer or people orientation | 15 | | | |
| Motivation and role fit | 15 | | | |
| Learning agility and adaptability | 10 | | | |
| Professionalism and integrity | 10 | | | |
| **Total** | **100** | | | |

## Overall assessment

| Item | Entry |
| --- | --- |
| Key strengths | |
| Areas of concern | |
| Salary expectation and notice or joining date | |
| Red flags (yes / no, details) | |

## Recommendation

| Total score | Recommendation | Tick one |
| --- | --- | --- |
| 80 to 100 | Strong hire: make an offer | |
| 65 to 79 | Hire: offer if openings remain | |
| 50 to 64 | Waitlist | |
| Below 50 | Reject | |

| Interviewer name | Signature | Date |
| --- | --- | --- |
| | | |
