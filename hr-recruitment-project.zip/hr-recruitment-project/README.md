# HR Management Assignment 1: Recruitment Process

Recruitment plan for hiring **10 fresh graduates** (5 Business Development Executives and 5 HR Executives) from **200 applications** within **15 days** (20 November to 4 December 2026).

## Contents

| File | Task |
| --- | --- |
| [01-job-descriptions.md](01-job-descriptions.md) | 1. Job descriptions for both positions (combined posting) |
| [02-skills-and-qualifications.md](02-skills-and-qualifications.md) | 2. Required skills and qualifications |
| [03-shortlisting-matrix.md](03-shortlisting-matrix.md) | 3. Candidate shortlisting evaluation matrix |
| [04-interview-questions.md](04-interview-questions.md) | 4. 15 interview questions per position |
| [05-interview-evaluation-sheet.md](05-interview-evaluation-sheet.md) | 5. Candidate interview evaluation sheet |
| [06-interview-invitation-email.md](06-interview-invitation-email.md) | 6. Interview invitation email |
| [07-rejection-email.md](07-rejection-email.md) | 7. Candidate rejection email |
| [08-recruitment-plan.md](08-recruitment-plan.md) | 8. 15-day recruitment plan |

## Assumptions

- Openings are split 5 and 5 between the two roles.
- Text in [square brackets] is a placeholder (company name, city, pay, dates).
- Recruitment funnel: 200 applications, 60 shortlisted, 36 interviewed, 20 final round, 10 offers plus 4 waitlisted.

## Author

[Your Name], [Course / Roll number]
