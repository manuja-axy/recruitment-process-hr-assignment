# Required Skills and Qualifications

| Area | Business Development Executive | HR Executive |
| --- | --- | --- |
| Education (must have) | Any graduate degree; BBA, BCom, BTech or MBA preferred | Graduate in any stream; BBA, BA (Psychology), BCom, MBA (HR) or PGDHRM preferred |
| Graduation year | 2025 or 2026, 0 to 1 year experience | 2025 or 2026, 0 to 1 year experience |
| Minimum academics | 60% or 6.5 CGPA, no active backlogs | 60% or 6.5 CGPA, no active backlogs |
| Core skills | Lead research, cold outreach, presentation, negotiation basics, understanding of IT services and the sales funnel | Recruitment basics, interviewing, HR policy awareness, MS Excel, documentation, basic labour law (PF, ESI, gratuity) |
| Tools | LinkedIn, MS Office, CRM exposure is a plus | MS Excel, Google Workspace, HRMS or ATS exposure is a plus |
| Communication | Fluent English; persuasive and confident on calls | Fluent English; clear, empathetic and professional in writing |
| Soft skills | Resilience, goal orientation, curiosity, self-motivation | Empathy, confidentiality, integrity, organisation, conflict handling |
| Good to have | Sales or marketing internship, campus ambassador role, sales certification | HR internship, placement cell work, HR certification, event organising |
| Other | Willing to travel occasionally and work toward targets | Willing to handle confidential data and work flexible hours at peak hiring |
