# Job Description: Fresher Hiring Drive

## 1. About Us and the Hiring Drive

[Company Name] is an IT services and solutions company based in [City, India]. We build software, cloud and support solutions for clients across [industries]. We value learning, ownership and teamwork.

| Detail | Information |
| --- | --- |
| Openings | 5 Business Development Executives, 5 HR Executives |
| Location | [City], [on-site / hybrid] |
| Expected joining date | [Date] |
| Last date to apply | [Date] |

## 2. Common Terms for Both Roles

- **Employment type:** Full time, permanent after probation.
- **Probation:** 6 months.
- **Working hours:** [9:30 AM to 6:30 PM], Monday to Friday.
- **Training:** Induction plus a 4-week role-specific programme.
- **Eligibility:** Graduate, minimum 60% or 6.5 CGPA, no active backlogs, 2025 or 2026 pass-out, fluent English.

## 3. Business Development Executive (5 openings)

**Role summary:** Generate and qualify leads for our IT services, support senior sales staff, and help turn prospects into clients.

**Reporting to:** Business Development Manager

**Key responsibilities**

- Research target companies and decision makers; build prospect lists.
- Reach prospects by email, phone and LinkedIn; book discovery calls and demos.
- Qualify leads on budget, need, authority and timeline.
- Prepare proposals, presentations and RFP responses with the technical team.
- Keep pipeline data accurate in the CRM and report weekly activity.
- Learn our IT services well enough to explain their business value.
- Follow up with clients and support renewals and cross-selling.

**Required skills and qualifications:** graduate degree (BBA, BCom, BTech or MBA preferred); strong communication and persuasion; basic sales funnel and negotiation knowledge; MS Office and LinkedIn; resilience and self-motivation.

**Good to have:** sales or marketing internship; CRM exposure (Zoho, HubSpot, Salesforce); sales or digital marketing certification.

**Performance measures (first 6 months):** qualified leads per month, meetings and demos booked, proposals supported and pipeline value, CRM accuracy.

**Growth path:** Business Development Executive, Senior Executive, Account Manager, Business Development Manager.

## 4. HR Executive (5 openings)

**Role summary:** Support the employee lifecycle, starting with recruitment, onboarding and HR operations.

**Reporting to:** HR Manager

**Key responsibilities**

- Source and screen candidates through job portals, LinkedIn and campuses.
- Schedule interviews, coordinate panels and keep candidates updated.
- Prepare offer letters, collect documents and manage joining formalities.
- Run induction programmes and keep HRMS records accurate.
- Support attendance, leave, payroll inputs and compliance (PF, ESI, gratuity).
- Help plan engagement activities, surveys and exit interviews.
- Answer policy queries and escalate sensitive cases to the HR Manager.

**Required skills and qualifications:** graduate degree (BBA, BA Psychology, BCom, MBA HR or PGDHRM preferred); strong communication and listening; good MS Excel; basic HR policy and labour law awareness; integrity and confidentiality.

**Good to have:** HR internship or placement cell experience; HRMS or ATS exposure; HR certification.

**Performance measures (first 6 months):** time to schedule interviews, candidate experience feedback, onboarding within timeline, HRMS accuracy and query response time.

**Growth path:** HR Executive, Senior HR Executive, HR Business Partner, HR Manager.

## 5. Role Comparison

| Item | Business Development Executive | HR Executive |
| --- | --- | --- |
| Openings | 5 | 5 |
| Department | Sales and Business Development | Human Resources |
| Reports to | Business Development Manager | HR Manager |
| Main focus | Lead generation, meetings, proposals | Recruitment, onboarding, HR operations |
| Key tools | LinkedIn, CRM, MS Office | MS Excel, HRMS or ATS |

## 6. Compensation and Benefits

- **Fixed pay:** [CTC range]
- **Incentive:** [Performance incentive for BD Executives; annual bonus for HR Executives]
- **Training:** Induction, 4-week programme and a mentor for 6 months.
- **Other benefits:** [Health insurance, paid leave, learning allowance]

## 7. How to Apply and Selection Process

Send your resume and a 5-line cover note to [careers email] with the subject "Application: [Position] - [Your Name]" by [last date].

1. Resume screening
2. Online assessment (aptitude, written communication, role scenario)
3. Interview round 1: functional panel
4. Interview round 2: department head and HR Manager
5. Verification and offer letter

[Company Name] is an equal opportunity employer.
