# Interview Questions (15 per Position)

Probe every answer with "What exactly did you do?" and "What was the result?"

## Business Development Executive

| # | Question | Assesses |
| --- | --- | --- |
| 1 | Tell me about yourself and why you chose business development. | Communication, motivation |
| 2 | Why do you want to work in sales for an IT company? | Role fit, industry interest |
| 3 | What do you understand by the sales funnel? Walk me through its stages. | Role knowledge |
| 4 | How would you find and qualify 20 potential clients for a software services company? | Lead generation, structure |
| 5 | Sell me this pen (or our cloud services) in two minutes. | Persuasion, thinking on feet |
| 6 | A prospect says "we already have a vendor." How do you respond? | Objection handling |
| 7 | Describe a time you persuaded someone to accept your idea. | Influence, results |
| 8 | How do you handle rejection after ten calls without a meeting? | Resilience |
| 9 | What is the difference between a feature and a benefit? Give an IT example. | Value communication |
| 10 | How would you research a company before a first call? | Preparation, initiative |
| 11 | Tell me about a target or goal you set and how you achieved it. | Goal orientation |
| 12 | A client asks for a discount you cannot approve. What do you do? | Negotiation, integrity |
| 13 | Write a two-line email opening to a retail CEO about digital transformation. | Written communication |
| 14 | How would you work with a technical team that says a client request is not feasible? | Collaboration |
| 15 | Where do you see yourself in three years, and what will you do to get there? | Ambition, learning mindset |

## HR Executive

| # | Question | Assesses |
| --- | --- | --- |
| 1 | Tell me about yourself and why you chose HR. | Communication, motivation |
| 2 | What does an HR Executive do in an IT company? | Role knowledge |
| 3 | Walk me through the recruitment process from requisition to joining. | Process knowledge |
| 4 | How would you screen 200 resumes quickly and fairly? | Structure, fairness |
| 5 | A hiring manager rejects every candidate you send. How do you handle it? | Stakeholder management |
| 6 | Two employees are in conflict. How do you handle the situation? | Conflict resolution |
| 7 | How would you keep an employee's sensitive information confidential? Give an example. | Integrity, confidentiality |
| 8 | How do you assess culture fit without bias? | Fairness, judgement |
| 9 | What are the key components of a good onboarding programme? | HR operations |
| 10 | An employee resigns citing poor management. What do you do in the exit interview? | Empathy, listening |
| 11 | What basic labour laws or statutory benefits have you studied (PF, ESI, gratuity)? | Compliance knowledge |
| 12 | Tell me about a time you managed multiple tasks with tight deadlines. | Organisation, prioritising |
| 13 | How would you improve engagement in a team of 50 developers? | Creativity, practical thinking |
| 14 | You find a candidate lied on their resume. What steps do you take? | Ethics, process |
| 15 | Which HR metric would you track first (attrition, time to hire, offer acceptance) and why? | Analytical thinking |
