# Candidate Rejection Email

Send one version after screening and a softer one after interviews. Never share scores or comparisons with other candidates.

**Subject:** Your Application for [Position] at [Company Name]

Dear [Candidate Name],

Thank you for applying for the position of [Business Development Executive / HR Executive] at [Company Name] and for the time you invested in our process.

After careful review, we have decided not to move forward with your application at this time. We received many strong applications for a small number of openings, and this decision reflects the specific requirements of this role, not your potential.

*Version for candidates interviewed:* We enjoyed meeting you and appreciated your [specific strength, e.g. clear communication].

With your consent, we would like to keep your profile on file for future openings that match your skills. We encourage you to apply again and wish you every success in your career.

Sincerely,
[Your Name]
HR Manager, [Company Name]
[Email]
