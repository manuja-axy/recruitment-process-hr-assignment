# Interview Invitation Email

Use the same template for each round; change the round name, date and format.

**Subject:** Interview Invitation: [Position] at [Company Name] | [Date]

Dear [Candidate Name],

Thank you for applying for the position of [Business Development Executive / HR Executive] at [Company Name]. We were impressed by your profile and would like to invite you to the next stage of our selection process.

**Interview details**

- Round: [Online assessment / Functional interview / Final interview]
- Date: [Day, Date]
- Time: [Time, IST] (please join 10 minutes early)
- Mode: [In person at address / Video link]
- Duration: About [45] minutes
- Panel: [Names and designations]

**Please bring or keep ready**

- Updated resume
- Government photo ID
- Mark sheets and degree certificate (or provisional certificate)
- Internship or project proof, if any

Please confirm your attendance by replying to this email by [date and time]. If the slot does not suit you, tell us by [date] with two alternative slots and we will try to accommodate you.

For any questions, contact [HR name] at [email] or [phone number].

We look forward to meeting you.

Warm regards,
[Your Name]
HR Manager, [Company Name]
[Phone] | [Email]
