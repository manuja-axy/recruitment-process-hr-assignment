# Candidate Shortlisting Evaluation Matrix

Screen all 200 applications in two passes. Shortlist the top 30 per role (about 60 in total).

## Pass 1: Eligibility check (any "No" means reject)

| Check | Yes / No |
| --- | --- |
| Graduate degree completed or final result due before joining | |
| Meets minimum 60% or 6.5 CGPA | |
| No active backlogs | |
| Graduation year 2025 or 2026 | |
| Application complete (resume, contact, consent) | |
| Willing to work in [City] and join by [date] | |

## Pass 2: Weighted scoring (100 points)

Score each criterion 0 to 5. Weighted score = (rating / 5) x weight.

| Criterion | Weight | What a 5 looks like |
| --- | --- | --- |
| Academic record | 15 | 75% or above, strong in relevant subjects |
| Relevant skills match | 25 | BD: sales, lead generation, CRM, presentation. HR: recruitment, Excel, HR policy, HRMS |
| Internships and projects | 20 | Relevant internship or project with measurable results |
| Communication and resume quality | 15 | Clear, error-free, well structured resume and cover note |
| Leadership and extracurriculars | 10 | Club or committee lead, event organiser, campus ambassador |
| Certifications and self-learning | 5 | Role-relevant course completed in last 12 months |
| Motivation and role fit | 10 | Cover note shows clear interest in the role and in an IT company |
| **Total** | **100** | |

## Decision bands

| Score | Decision | Next step |
| --- | --- | --- |
| 70 and above | Shortlist | Online assessment (Day 6) |
| 55 to 69 | Hold | Reconsider only if fewer than 30 shortlisted per role |
| Below 55 | Reject | Rejection email (Day 6) |

## Scoring sheet

| Candidate ID | Name | Role | Pass 1 | Academic (15) | Skills (25) | Internships (20) | Communication (15) | Leadership (10) | Certifications (5) | Motivation (10) | Total (100) | Decision | Screener |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | | | | | | | |

**Quality control:** two screeners score the first 10 resumes together to align ratings; the HR Manager re-checks a 10% random sample of shortlisted and rejected candidates.
