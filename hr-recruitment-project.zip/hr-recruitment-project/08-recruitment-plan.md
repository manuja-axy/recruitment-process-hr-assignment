# 15-Day Recruitment Plan

Friday 20 November to Friday 4 December 2026. Weekends are used only for desk screening and interviews; Sunday is a rest day.

**Funnel:** 200 applications, 60 shortlisted (Day 4), 36 interviewed (Days 8 and 9), 20 final round (Day 11), 10 offers plus 4 waitlist (Day 12).

| Day | Date | Activity | Owner | Output |
| --- | --- | --- | --- | --- |
| 1 | Fri 20 Nov | Kick-off with hiring managers; approve job descriptions, scoring matrix and panel; set up tracker | HR Manager | Approved criteria and tracker |
| 2 | Sat 21 Nov | Pass 1 eligibility check on all 200 applications; send acknowledgement emails | HR team | Eligible list |
| 3 | Sun 22 Nov | Rest day | | |
| 4 | Mon 23 Nov | Pass 2 scoring; screener calibration; select top 30 per role | HR team | 60 shortlisted |
| 5 | Tue 24 Nov | Managers review shortlist; finalise assessment; send assessment invitations | HR Manager, managers | 60 approved, invitations sent |
| 6 | Wed 25 Nov | Online assessment; send rejection emails to screened-out candidates | HR team | Assessment scores, rejections sent |
| 7 | Thu 26 Nov | Evaluate assessments; shortlist 18 per role; send interview invitations | HR team | 36 interview slots confirmed |
| 8 | Fri 27 Nov | Functional interviews, batch 1 (18 candidates), two panels | Panels | Evaluation sheets |
| 9 | Sat 28 Nov | Functional interviews, batch 2 (18 candidates) | Panels | Evaluation sheets |
| 10 | Sun 29 Nov | Rest day; HR consolidates scores in the background | | |
| 11 | Mon 30 Nov | Final round with department head and HR Manager for top 20 (10 per role) | Department heads | Final scores |
| 12 | Tue 1 Dec | Decision panel selects 10 hires and 4 waitlist; start reference and document checks; compensation approval | Panel, HR Manager | Selection list |
| 13 | Wed 2 Dec | Management approval; prepare offer letters; rejection emails to interviewed candidates | HR Manager, Finance | Approved offers |
| 14 | Thu 3 Dec | Release 10 offer letters; inform waitlisted candidates | HR team | Offers issued |
| 15 | Fri 4 Dec | Collect acceptances; confirm joining dates; activate waitlist if needed; close recruitment report | HR Manager | Signed offers and report |

## Resources and controls

- **Team:** HR Manager, 2 HR screeners, 2 interview panels (a department head plus an HR member each).
- **Tools:** tracking spreadsheet or ATS, video meeting link, online assessment platform, email templates.
- **Daily check:** 15-minute stand-up at 10:00 to review counts against the funnel.
- **Fairness and compliance:** same questions for every candidate, written scores before discussion, candidate data kept confidential.

## Risks and fallbacks

| Risk | Fallback |
| --- | --- |
| Fewer than 30 qualified candidates for one role | Use the 55 to 69 "hold" band and extend the assessment invite |
| Panel members unavailable | Appoint two alternates on Day 1 and keep one buffer interview slot |
| Offer declines | Activate the 4 waitlisted candidates on Day 15 |
| High candidate no-shows | Send reminders 24 hours and 2 hours before each slot and overbook by 10% |
